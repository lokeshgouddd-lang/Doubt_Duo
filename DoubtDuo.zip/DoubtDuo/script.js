// Open the Doubt Posting Page
function askDoubt() {
    window.location.href = "doubts.html";
}

// Get saved doubts
let doubts = JSON.parse(localStorage.getItem("doubts")) || [];

// Get HTML elements
const doubtForm = document.getElementById("doubtForm");
const doubtList = document.getElementById("doubtList");

// Display all doubts and their answers
function displayDoubts() {

    if (!doubtList) return;

    doubtList.innerHTML = "";

    doubts.forEach(function(doubt, index) {

        // Make sure every doubt has an answers list
        doubt.answers = doubt.answers || [];

        const card = document.createElement("div");
        card.className = "doubt-card";

                    const author = document.createElement("p");

            author.textContent = "Posted by: " + (doubt.author || "Previous Student");

            card.appendChild(author);

        const title = document.createElement("h3");
        title.textContent = doubt.title;

        const subject = document.createElement("span");
        subject.className = "subject-tag";
        subject.textContent = doubt.subject;

        const description = document.createElement("p");
        description.textContent = doubt.description;
        card.appendChild(description);

        if (window.renderMathInElement) {
            renderMathInElement(description, {
                delimiters: [
                    {left: "$$", right: "$$", display: true},
                    {left: "$", right: "$", display: false}
                ]
            });
        }

        card.appendChild(title);
        card.appendChild(subject);
        

                    const bountyInfo = document.createElement("p");

            bountyInfo.textContent = "⭐ Bounty: " + (doubt.bounty || 0) + " Karma";

            card.appendChild(bountyInfo);

        // Answers section
        const answerSection = document.createElement("div");
        answerSection.className = "answer-section";

        const answerHeading = document.createElement("h4");
        answerHeading.textContent = "Answers";
        answerSection.appendChild(answerHeading);

        // Display saved answers
doubt.answers.forEach(function(answer, answerIndex) {

    const answerBox = document.createElement("div");
    answerBox.className = "answer-item";

    if (doubt.acceptedAnswer === answerIndex) {
        answerBox.classList.add("accepted-answer");
    }

    const tutorName = document.createElement("p");

tutorName.textContent = "Tutor: " +
    (typeof answer === "string" ? "Previous Student" : answer.tutor);

const answerText = document.createElement("p");

answerText.textContent =
    typeof answer === "string" ? answer : answer.text;

answerBox.appendChild(tutorName);
answerBox.appendChild(answerText);

// Helpful answer upvote
if (typeof answer !== "string") {

    answer.upvotedBy = answer.upvotedBy || [];

    const upvoteButton = document.createElement("button");

    upvoteButton.textContent =
        "👍 Helpful (" + answer.upvotedBy.length + ")";

    upvoteButton.addEventListener("click", function() {

        const currentUser = JSON.parse(
            localStorage.getItem("currentUser")
        );

        if (!currentUser) {
            alert("Please login to upvote!");
            return;
        }

        if (currentUser.email === answer.tutorEmail) {
            alert("You cannot upvote your own answer!");
            return;
        }

        if (answer.upvotedBy.includes(currentUser.email)) {
            alert("You have already upvoted this answer!");
            return;
        }

        answer.upvotedBy.push(currentUser.email);

        // Give 5 Karma to the tutor
        let users = JSON.parse(localStorage.getItem("users")) || [];

        const tutor = users.find(function(user) {
            return user.email === answer.tutorEmail;
        });

        if (tutor) {
            tutor.karma = (Number(tutor.karma) || 0) + 5;
            localStorage.setItem("users", JSON.stringify(users));
        }

        // Update Karma if the tutor is currently logged in
        if (currentUser.email === answer.tutorEmail) {
            let karma = Number(localStorage.getItem("karma")) || 0;
            localStorage.setItem("karma", karma + 5);
        }

        localStorage.setItem("doubts", JSON.stringify(doubts));

        alert("Thanks! The tutor earned 5 Karma.");

        displayDoubts();
    });

    answerBox.appendChild(upvoteButton);
}

    if (doubt.acceptedAnswer === answerIndex && doubt.karmaAwarded) {
    const rewardMessage = document.createElement("p");
    const bounty = Number(doubt.bounty) || 0;

    rewardMessage.textContent =
        "🎉 Reward Earned: +" + (25 + bounty) +
        " Karma (25 Answer Reward + " + bounty + " Bounty)";

    rewardMessage.style.color = "green";
    rewardMessage.style.fontWeight = "bold";

    answerBox.appendChild(rewardMessage);
}

    const acceptButton = document.createElement("button");
    acceptButton.textContent =
        doubt.acceptedAnswer === answerIndex
        ? "Accepted Answer"
        : "Accept Answer";

    acceptButton.addEventListener("click", function() {

        if (doubt.acceptedAnswer === undefined || doubt.acceptedAnswer === null)  {

            const currentUser = JSON.parse(localStorage.getItem("currentUser"));

            if (!currentUser || currentUser.email !== doubt.authorEmail) {
                alert("Only the question owner can accept an answer!");
                return;
            }

    doubt.acceptedAnswer = answerIndex;

    let karma = Number(localStorage.getItem("karma")) || 0;

    if (!doubt.karmaAwarded) {
    let bounty = Number(doubt.bounty) || 0;

    karma = karma + 25 + bounty;

    doubt.karmaAwarded = true;
    doubt.bountyAwarded = true;

    localStorage.setItem("karma", karma);
}

    localStorage.setItem("doubts", JSON.stringify(doubts));
}

displayDoubts();
    });

    answerBox.appendChild(acceptButton);
    answerSection.appendChild(answerBox);
});

        // Answer form
        const answerForm = document.createElement("form");
        answerForm.className = "answer-form";

        const answerInput = document.createElement("textarea");
        answerInput.placeholder = "Write your answer here...";
        answerInput.required = true;

        const answerButton = document.createElement("button");
        answerButton.type = "submit";
        answerButton.textContent = "Submit Answer";

        answerForm.appendChild(answerInput);
        answerForm.appendChild(answerButton);

        answerForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const answer = answerInput.value.trim();

    if (answer === "") return;

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    if (!currentUser) {
        alert("Please login before answering!");
        return;
    }

    if (currentUser.email === doubts[index].authorEmail) {
        alert("You cannot answer your own doubt!");
        return;
    }

    doubts[index].answers.push({
        text: answer,
        tutor: currentUser.name,
        tutorEmail: currentUser.email
    });

    localStorage.setItem("doubts", JSON.stringify(doubts));

    displayDoubts();
});

        answerSection.appendChild(answerForm);
        card.appendChild(answerSection);

        doubtList.appendChild(card);
    });

    localStorage.setItem("doubts", JSON.stringify(doubts));
}

// Handle doubt submission
if (doubtForm) {

    doubtForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const title = document.getElementById("questionTitle").value;
        const subject = document.getElementById("questionSubject").value;
        const description = document.getElementById("questionDescription").value;

        let bounty = Number(document.getElementById("bountyPoints").value);

            const currentUser = JSON.parse(localStorage.getItem("currentUser"));

            const newDoubt = {
                title: title,
                subject: subject,
                description: description,
                author: currentUser ? currentUser.name : "Unknown Student",
                authorEmail: currentUser ? currentUser.email : "",
                answers: [],
                bounty: bounty,
                bountyAwarded: false
            };

                        let currentKarma = Number(localStorage.getItem("karma")) || 0;

                if (bounty > currentKarma) {
            alert("Insufficient Karma! Your doubt will be posted without a bounty.");
            bounty = 0;
            newDoubt.bounty = 0;
        } else {
            currentKarma = currentKarma - bounty;
            localStorage.setItem("karma", currentKarma);
}

        doubts.unshift(newDoubt);

        localStorage.setItem("doubts", JSON.stringify(doubts));

        doubtForm.reset();

        displayDoubts();

        alert("Your doubt has been posted successfully!");
    });
}

// Show previously posted doubts
displayDoubts();

function showKarma() {
    let karma = Number(localStorage.getItem("karma")) || 0;

    alert("Your total Karma points: " + karma);
}

function updateKarma() {
    const karmaDisplay = document.getElementById("karmaPoints");

    if (karmaDisplay) {
        let karma = Number(localStorage.getItem("karma")) || 0;
        karmaDisplay.textContent = karma;
    }
}

updateKarma();

const tutorSearch = document.getElementById("tutorSearch");

if (tutorSearch) {

    tutorSearch.addEventListener("input", function() {

        const searchValue = tutorSearch.value.toLowerCase();

        const tutorCards = document.querySelectorAll(".tutor-card");

        tutorCards.forEach(function(card) {

            const tutorDetails = card.textContent.toLowerCase();

            if (tutorDetails.includes(searchValue)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }

        });

    });

}

function viewTutor(name) {
    window.location.href = "tutor-profile.html?name=" + name;
}

const tutorProfiles = {
    Rahul: {
        subject: "Mathematics",
        skills: "Matrices, Calculus",
        karma: 120
    },

    Priya: {
        subject: "Programming",
        skills: "C, Python",
        karma: 200
    },

    Arjun: {
        subject: "Physics",
        skills: "Mechanics, Optics",
        karma: 95
    }
};

const tutorNameElement = document.getElementById("tutorName");

if (tutorNameElement) {

    const params = new URLSearchParams(window.location.search);
    const name = params.get("name");

    const tutor = tutorProfiles[name];

    if (tutor) {
        tutorNameElement.textContent = name;
        document.getElementById("tutorSubject").textContent =
            "Subject: " + tutor.subject;

        document.getElementById("tutorSkills").textContent =
            "Skills: " + tutor.skills;

        document.getElementById("tutorKarma").textContent =
            "⭐ " + tutor.karma + " Karma Points";
    } else {
        tutorNameElement.textContent = "Tutor not found";
    }
}

// Peer Session Booking

const bookingForm = document.getElementById("bookingForm");

if (bookingForm) {

    bookingForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const tutor = document.getElementById("bookingTutor").value;
        const date = document.getElementById("bookingDate").value;
        const time = document.getElementById("bookingTime").value;

        const newBooking = {
            tutor: tutor,
            date: date,
            time: time,
            duration: "30 Minutes"
        };

        let bookings = JSON.parse(localStorage.getItem("bookings")) || [];

        const alreadyBooked = bookings.some(function(booking) {
    return booking.tutor === tutor &&
           booking.date === date &&
           booking.time === time;
});

if (alreadyBooked) {
    document.getElementById("bookingMessage").textContent =
        "You have already booked this tutor at this time.";
    return;
}

bookings.push(newBooking);

        localStorage.setItem("bookings", JSON.stringify(bookings));

        document.getElementById("bookingMessage").textContent =
            "Your session with " + tutor + " has been booked successfully!";

        bookingForm.reset();
    });

}

// Display My Bookings

const bookingsList = document.getElementById("bookingsList");

if (bookingsList) {

    let bookings = JSON.parse(localStorage.getItem("bookings")) || [];

    if (bookings.length === 0) {

        bookingsList.textContent = "You have no bookings yet.";

    } else {

        bookings.forEach(function(booking) {

            const card = document.createElement("div");
            card.className = "booking-card";

            const title = document.createElement("h3");
            title.textContent = "Session with " + booking.tutor;

            const date = document.createElement("p");
            date.textContent = "Date: " + booking.date;

            const time = document.createElement("p");
            time.textContent = "Time: " + booking.time;

            const duration = document.createElement("p");
            duration.textContent = "Duration: " + booking.duration;

            card.appendChild(title);
            card.appendChild(date);
            card.appendChild(time);
            card.appendChild(duration);

            bookingsList.appendChild(card);

        });

    }

}

// Tutor Rating and Review System

const reviewForm = document.getElementById("reviewForm");
const reviewsList = document.getElementById("reviewsList");

if (reviewForm && reviewsList) {

    const params = new URLSearchParams(window.location.search);
    const tutorName = params.get("name");

    let allReviews = JSON.parse(localStorage.getItem("reviews")) || [];

    function displayReviews() {

        reviewsList.innerHTML = "";

        const tutorReviews = allReviews.filter(function(review) {
            return review.tutor === tutorName;
        });

        tutorReviews.forEach(function(review) {

            const card = document.createElement("div");
            card.className = "review-card";

            const rating = document.createElement("p");
            rating.textContent = "Rating: " + "⭐".repeat(review.rating);

            const comment = document.createElement("p");
            comment.textContent = review.comment;

            card.appendChild(rating);
            card.appendChild(comment);

            reviewsList.appendChild(card);

        });
    }

    reviewForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const rating = Number(document.getElementById("tutorRating").value);
        const comment = document.getElementById("tutorReview").value.trim();

        if (!comment) return;

        const newReview = {
            tutor: tutorName,
            rating: rating,
            comment: comment
        };

        allReviews.push(newReview);

        localStorage.setItem("reviews", JSON.stringify(allReviews));

        reviewForm.reset();

        displayReviews();

        alert("Your review has been submitted!");
    });

    displayReviews();
}

// Update Tutor Achievement Badge

function updateTutorBadge() {

    const badge = document.getElementById("tutorBadge");

    if (!badge) return;

    const karma = Number(localStorage.getItem("karma")) || 0;

    if (karma >= 300) {
        badge.textContent = "🏆 Gold Scholar";
    } else if (karma >= 150) {
        badge.textContent = "🥈 Silver Sage";
    } else if (karma >= 50) {
        badge.textContent = "🥉 Bronze Tutor";
    } else {
        badge.textContent = "🌱 New Learner";
    }
}

updateTutorBadge();

// Student Leaderboard

const leaderboardList = document.getElementById("leaderboardList");

if (leaderboardList) {

    const students = [
        { name: "Rahul", karma: 200 },
        { name: "Priya", karma: 150 },
        { name: "Arjun", karma: 100 },
        {
            name: "You",
            karma: Number(localStorage.getItem("karma")) || 0
        }
    ];

    students.sort(function(a, b) {
        return b.karma - a.karma;
    });

    students.forEach(function(student, index) {

        const card = document.createElement("div");
        card.className = "leaderboard-card";

        const details = document.createElement("div");

        const name = document.createElement("h3");
        name.textContent =
            (index + 1) + ". " + student.name;

        const points = document.createElement("p");
        points.textContent = "Karma Points: " + student.karma;

        details.appendChild(name);
        details.appendChild(points);

        const nomination = document.createElement("p");

        if (student.karma >= 300) {
            nomination.textContent = "🏆 TA Nomination Eligible";
        } else {
            nomination.textContent = "Keep contributing to reach 300 Karma!";
        }

        card.appendChild(nomination);

        const rank = document.createElement("strong");

        if (index === 0) {
            rank.textContent = "🥇";
        } else if (index === 1) {
            rank.textContent = "🥈";
        } else if (index === 2) {
            rank.textContent = "🥉";
        } else {
            rank.textContent = "⭐";
        }

        card.appendChild(details);
        card.appendChild(rank);

        leaderboardList.appendChild(card);

    });

}

const signupFormElement = document.getElementById("signupForm");

if (signupFormElement) {
    signupFormElement.addEventListener("submit", function(event) {
        event.preventDefault();

        const name = document.getElementById("signupName").value.trim();
        const email = document.getElementById("signupEmail").value.trim();
        const password = document.getElementById("signupPassword").value;

        let users = JSON.parse(localStorage.getItem("users")) || [];

        const existingUser = users.find(function(user) {
            return user.email === email;
        });

        if (existingUser) {
            alert("This email is already registered!");
            return;
        }

        const newUser = {
            name: name,
            email: email,
            password: password
        };

        users.push(newUser);

        localStorage.setItem("users", JSON.stringify(users));
        localStorage.setItem("currentUser", JSON.stringify({
            name: name,
            email: email
        }));

        alert("Account created successfully!");

        window.location.href = "index.html";
    });
} 

function runCode() {
    const code = document.getElementById("codeEditor").value;
    const language = document.getElementById("languageSelect").value;
    const output = document.getElementById("codeOutput");

    if (code.trim() === "") {
        output.textContent = "Please write some code first!";
        return;
    }

    if (language !== "javascript") {
        output.textContent =
            language.toUpperCase() +
            " execution will be available after backend integration.";
        return;
    }

    let results = [];

    const customConsole = {
        log: function(...values) {
            results.push(values.join(" "));
        }
    };

    try {
        const result = new Function("console", code)(customConsole);

        if (results.length > 0) {
            output.textContent = results.join("\n");
        } else {
            output.textContent =
                result === undefined
                    ? "Code executed successfully!"
                    : result;
        }

    } catch (error) {
        output.textContent = error.message;
    }
}

function clearCode() {
    document.getElementById("codeEditor").value = "";

    document.getElementById("codeOutput").textContent =
        "Your output will appear here.";
}

function copyCode() {
    const code = document.getElementById("codeEditor").value;

    if (code.trim() === "") {
        alert("There is no code to copy!");
        return;
    }

    navigator.clipboard.writeText(code)
        .then(function() {
            alert("Code copied successfully!");
        })
        .catch(function() {
            alert("Unable to copy code.");
        });
}

// Connect Scratchpad to the backend
let collaborationSocket = null;

if (document.getElementById("codeEditor") && typeof io !== "undefined") {
    collaborationSocket = io("http://localhost:3000");
}
let activeRoomId = "";

function createRoom() {
    const roomId = "ROOM" + Math.floor(1000 + Math.random() * 9000);

    activeRoomId = roomId;

    document.getElementById("roomId").value = roomId;

    collaborationSocket.emit("join-room", roomId);

    document.getElementById("roomStatus").textContent =
        "You created room: " + roomId;
}

function joinRoom() {
    const roomId = document.getElementById("roomId").value.trim();

    if (roomId === "") {
        alert("Please enter a Room ID!");
        return;
    }

    activeRoomId = roomId;

    collaborationSocket.emit("join-room", roomId);

    document.getElementById("roomStatus").textContent =
        "You joined room: " + roomId;
}

const codeEditorElement = document.getElementById("codeEditor");

if (codeEditorElement) {
    codeEditorElement.addEventListener("input", function() {
        if (activeRoomId !== "" && collaborationSocket) {
            collaborationSocket.emit("code-change", {
                roomId: activeRoomId,
                code: codeEditorElement.value
            });
        }
    });
}

if (collaborationSocket) {
    collaborationSocket.on("code-update", function(code) {
        codeEditorElement.value = code;
    });
}

// Subject learning content
const subjectData = {
    Mathematics: {
        description: "Mathematics helps us solve problems using numbers, formulas and logical thinking.",
        topics: [
            "Matrices – Learn rows, columns, addition and multiplication of matrices.",
            "Calculus – Understand limits, differentiation and integration.",
            "Algebra – Learn equations, variables and mathematical expressions.",
            "Statistics – Understand mean, median and mode."
        ]
    },

    Programming: {
        description: "Programming teaches you how to give instructions to computers and build applications.",
        topics: [
            "C Programming – Learn variables, conditions, loops and functions.",
            "Python – Learn syntax, data types, lists and dictionaries.",
            "Java – Understand classes, objects and methods.",
            "Problem Solving – Practice coding questions and logical thinking."
        ]
    },

    Physics: {
        description: "Physics helps us understand how the world works through scientific principles.",
        topics: [
            "Mechanics – Learn motion, force and Newton's laws.",
            "Work and Energy – Understand work, power and energy.",
            "Electricity – Learn current, voltage and resistance.",
            "Optics – Understand reflection and refraction of light."
        ]
    },

    Electronics: {
        description: "Electronics teaches how electrical components work together in circuits and devices.",
        topics: [
            "Basic Components – Learn about resistors, capacitors and diodes.",
            "Semiconductors – Understand conductors, insulators and semiconductors.",
            "Diodes – Learn how current flows through a diode.",
            "Digital Electronics – Understand logic gates and binary numbers."
        ]
    }
};

function showSubject(subject) {
    const data = subjectData[subject];

    document.getElementById("learningTitle").textContent =
        "Learn " + subject;

    document.getElementById("learningDescription").textContent =
        data.description;

    const topicsArea = document.getElementById("learningTopics");
    topicsArea.innerHTML = "";

    data.topics.forEach(function(topic) {
        const topicItem = document.createElement("p");
        topicItem.textContent = "📘 " + topic;
        topicsArea.appendChild(topicItem);
    });

    document.getElementById("subjectLearning").style.display = "block";

    document.getElementById("subjectLearning").scrollIntoView({
        behavior: "smooth"
    });
}

function closeSubject() {
    document.getElementById("subjectLearning").style.display = "none";
}


// Search tutors by subject or name
// Tutor search
const searchBox = document.getElementById("tutorSearch");

if (searchBox) {
    searchBox.addEventListener("input", function() {

        const searchValue = searchBox.value.toLowerCase();
        const cards = document.querySelectorAll(".tutor-card");

        cards.forEach(function(card) {

            const details = card.textContent.toLowerCase();

            if (details.includes(searchValue)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }

        });

    });
}

const bookingDate = document.getElementById("bookingDate");

if (bookingDate) {
    const today = new Date().toISOString().split("T")[0];
    bookingDate.min = today;
}


const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const password = document.getElementById("loginPassword").value;

        let users = JSON.parse(localStorage.getItem("users")) || [];

        const matchedUser = users.find(function(user) {
            return user.email === email &&
                   user.password === password;
        });

        if (matchedUser) {

            localStorage.setItem("currentUser", JSON.stringify({
                name: matchedUser.name,
                email: matchedUser.email
            }));

            alert("Login successful! Welcome " + matchedUser.name);

            window.location.href = "index.html";

        } else {
            document.getElementById("loginMessage").textContent =
                "Invalid email or password!";
        }
    });
}


// Profile dropdown functionality

const doubtDuoNavUser = JSON.parse(
    localStorage.getItem("currentUser")
);

const navButtons = document.getElementById("navButtons");
const profileMenu = document.getElementById("profileMenu");
const profileToggle = document.getElementById("profileToggle");
const profileDropdown = document.getElementById("profileDropdown");

if (doubtDuoNavUser && profileMenu) {

    navButtons.style.display = "none";
    profileMenu.style.display = "block";

    const initial = doubtDuoNavUser.name.charAt(0).toUpperCase();

    document.getElementById("profileInitial").textContent = initial;
    document.getElementById("dropdownInitial").textContent = initial;

    document.getElementById("dropdownName").textContent =
        doubtDuoNavUser.name;

    document.getElementById("dropdownEmail").textContent =
        doubtDuoNavUser.email;
}

// Open and close dropdown
if (profileToggle) {
    profileToggle.addEventListener("click", function() {
        profileDropdown.classList.toggle("show");
    });
}

// Close dropdown when clicking outside
document.addEventListener("click", function(event) {
    if (profileMenu && !profileMenu.contains(event.target)) {
        profileDropdown.classList.remove("show");
    }
});

// Logout
const navLogout = document.getElementById("navLogout");

if (navLogout) {
    navLogout.addEventListener("click", function() {
        if (confirm("Are you sure you want to logout?")) {
            localStorage.removeItem("currentUser");
            window.location.href = "login.html";
        }
    });
}


const subjectLessons = {

    Mathematics: {
        description: "Learn mathematical concepts, understand formulas and solve problems step by step.",
        topics: [
            {
                title: "1. Matrices",
                explanation: "A matrix is a rectangular arrangement of numbers in rows and columns. Matrices are used to organize data and solve mathematical problems.",
                points: [
                    "Types of matrices: Row, Column, Square and Zero.",
                    "Matrix addition and subtraction.",
                    "Matrix multiplication.",
                    "Transpose and inverse of a matrix."
                ],
                example: "A = [[1, 2], [3, 4]] is a 2 × 2 matrix. It has 2 rows and 2 columns.",
                application: "Matrices are used in computer graphics, engineering and machine learning."
            },
            {
                title: "2. Differential Calculus",
                explanation: "Differential calculus studies how quantities change. Differentiation helps us calculate the rate of change of a function.",
                points: [
                    "Limits and continuity.",
                    "Derivatives of functions.",
                    "Product and quotient rules.",
                    "Chain rule and applications."
                ],
                example: "If f(x) = x², then its derivative is f'(x) = 2x.",
                application: "Used to calculate speed, acceleration and optimization."
            },
            {
                title: "3. Integral Calculus",
                explanation: "Integration is the reverse process of differentiation. It helps calculate accumulated quantities and areas.",
                points: [
                    "Basic integration formulas.",
                    "Integration by substitution.",
                    "Integration by parts.",
                    "Definite and indefinite integrals."
                ],
                example: "The integral of 2x with respect to x is x² + C.",
                application: "Used to calculate areas, volumes and accumulated quantities."
            }
        ]
    },

    Programming: {
        description: "Develop programming skills from basic concepts to practical coding.",
        topics: [
            {
                title: "1. C Programming",
                explanation: "C is a procedural programming language used to develop efficient programs and understand computer fundamentals.",
                points: [
                    "Variables and data types.",
                    "Operators and expressions.",
                    "If, else and switch statements.",
                    "Loops, functions and arrays."
                ],
                example: "int a = 10; int b = 20; printf(\"%d\", a + b);",
                application: "Used in operating systems, embedded systems and system programming."
            },
            {
                title: "2. Python Programming",
                explanation: "Python is a beginner-friendly programming language known for its simple syntax and powerful libraries.",
                points: [
                    "Variables and data types.",
                    "Conditions and loops.",
                    "Lists, tuples and dictionaries.",
                    "Functions and object-oriented programming."
                ],
                example: "name = 'Roshan'\\nprint('Hello', name)",
                application: "Used in AI, machine learning, automation and data science."
            },
            {
                title: "3. Java Programming",
                explanation: "Java is an object-oriented programming language used to create applications across different platforms.",
                points: [
                    "Classes and objects.",
                    "Variables and methods.",
                    "Inheritance and polymorphism.",
                    "Exception handling."
                ],
                example: "int number = 10;\\nSystem.out.println(number);",
                application: "Used in enterprise software and Android application development."
            }
        ]
    },

    Physics: {
        description: "Understand the laws of nature and their applications in engineering and technology.",
        topics: [
            {
                title: "1. Mechanics",
                explanation: "Mechanics studies the motion of objects and the forces acting on them.",
                points: [
                    "Distance and displacement.",
                    "Speed and velocity.",
                    "Acceleration.",
                    "Newton's laws of motion."
                ],
                example: "Velocity = Displacement / Time.",
                application: "Used in vehicle design, robotics and mechanical engineering."
            },
            {
                title: "2. Electricity",
                explanation: "Electricity deals with electric charges, current, voltage and electrical circuits.",
                points: [
                    "Electric charge.",
                    "Electric current and voltage.",
                    "Resistance.",
                    "Ohm's law."
                ],
                example: "Ohm's Law: V = I × R.",
                application: "Used in electrical devices, power systems and electronic equipment."
            },
            {
                title: "3. Magnetism",
                explanation: "Magnetism is the physical phenomenon produced by moving electric charges and magnetic materials.",
                points: [
                    "Magnetic fields.",
                    "Magnetic force.",
                    "Electromagnetic induction.",
                    "Faraday's law."
                ],
                example: "A current-carrying wire produces a magnetic field around it.",
                application: "Used in electric motors, generators and transformers."
            }
        ]
    },

    Electronics: {
        description: "Explore electronic components, circuits and the working principles of electronic devices.",
        topics: [
            {
                title: "1. Basic Electronic Components",
                explanation: "Electronic components are the building blocks used to create electronic circuits.",
                points: [
                    "Resistors and capacitors.",
                    "Diodes and LEDs.",
                    "Transistors.",
                    "Inductors."
                ],
                example: "A resistor limits the flow of electric current in a circuit.",
                application: "Used in mobile phones, computers and electronic appliances."
            },
            {
                title: "2. Semiconductor Devices",
                explanation: "Semiconductors are materials whose electrical conductivity can be controlled. They are essential for modern electronics.",
                points: [
                    "Conductors, insulators and semiconductors.",
                    "P-type and N-type materials.",
                    "PN junction diode.",
                    "Transistor working principles."
                ],
                example: "A PN junction diode allows current to flow mainly in one direction.",
                application: "Used in processors, memory chips and power supplies."
            },
            {
                title: "3. Digital Electronics",
                explanation: "Digital electronics works with binary values, usually represented by 0 and 1.",
                points: [
                    "Binary number system.",
                    "Logic gates.",
                    "Boolean algebra.",
                    "Combinational circuits."
                ],
                example: "An AND gate gives output 1 only when both inputs are 1.",
                application: "Used in computers, calculators and digital systems."
            }
        ]
    }
};


// Open selected subject
function showSubject(subject) {

    const selectedSubject = subjectLessons[subject];

    if (!selectedSubject) {
        alert("Subject lessons are not available.");
        return;
    }

    document.getElementById("learningTitle").textContent =
        "📚 " + subject;

    document.getElementById("learningDescription").textContent =
        selectedSubject.description;

    const topicsContainer =
        document.getElementById("learningTopics");

    topicsContainer.innerHTML = "";

    selectedSubject.topics.forEach(function(topic) {

        const lessonCard = document.createElement("div");

        lessonCard.className = "lesson-card";

        lessonCard.innerHTML = `
            <h3>${topic.title}</h3>

            <p>${topic.explanation}</p>

            <h4>Important Concepts</h4>

            <ul>
                ${topic.points.map(function(point) {
                    return `<li>${point}</li>`;
                }).join("")}
            </ul>

            <h4>Example</h4>

            <div class="example">
                ${topic.example.replace(/\n/g, "<br>")}
            </div>

            <h4>Real-World Applications</h4>

            <p>${topic.application}</p>
        `;

        topicsContainer.appendChild(lessonCard);
    });

    document.getElementById("subjectLearning").style.display = "block";

    document.getElementById("subjectLearning").scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}


// Close learning portal
function closeSubject() {

    document.getElementById("subjectLearning").style.display = "none";

}

// =====================================
// SMART PEER TUTOR MATCHING SYSTEM
// =====================================

const peerTutorDirectory = [
    {
        name: "Rahul",
        subject: "Mathematics",
        skills: ["Matrices", "Calculus"],
        karma: 120
    },
    {
        name: "Priya",
        subject: "Programming",
        skills: ["C", "Python"],
        karma: 200
    },
    {
        name: "Arjun",
        subject: "Physics",
        skills: ["Mechanics", "Optics"],
        karma: 95
    }
];

// Find matching tutors
const matchButton = document.getElementById("findTutorMatches");

if (matchButton) {

    matchButton.addEventListener("click", function() {

        const selectedSubject =
            document.getElementById("tutorSubjectFilter").value;

        const results =
            document.getElementById("recommendedTutors");

        results.innerHTML = "";

        if (selectedSubject === "") {
            results.textContent = "Please select a subject first!";
            return;
        }

        // Filter tutors by subject
        let matches = peerTutorDirectory.filter(function(tutor) {
            return tutor.subject === selectedSubject;
        });

        // Sort tutors by Karma
        matches.sort(function(a, b) {
            return b.karma - a.karma;
        });

        if (matches.length === 0) {
            results.textContent =
                "No tutors are currently available for this subject.";
            return;
        }

        // Display recommended tutors
        matches.forEach(function(tutor, index) {

            const card = document.createElement("div");
            card.className = "match-card";

            const heading = document.createElement("h3");

            heading.textContent =
                (index === 0 ? "🏆 Best Match: " : "⭐ ") +
                tutor.name;

            const subject = document.createElement("p");
            subject.textContent = "Subject: " + tutor.subject;

            const skills = document.createElement("p");
            skills.textContent =
                "Skills: " + tutor.skills.join(", ");

            const karma = document.createElement("p");
            karma.textContent = "Karma: " + tutor.karma;

            const button = document.createElement("button");
            button.textContent = "View Profile";

            button.addEventListener("click", function() {
                viewTutor(tutor.name);
            });

            card.appendChild(heading);
            card.appendChild(subject);
            card.appendChild(skills);
            card.appendChild(karma);
            card.appendChild(button);

            results.appendChild(card);

        });

    });

}