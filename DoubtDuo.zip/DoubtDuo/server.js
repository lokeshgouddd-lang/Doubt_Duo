const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);

app.use(express.static(__dirname));

const io = new Server(server);

io.on("connection", function(socket) {
    console.log("A student connected:", socket.id);

    socket.on("join-room", function(roomId) {
        if (roomId.trim() === "") {
            return;
        }

        socket.join(roomId);
        console.log("Student joined room:", roomId);
    });

    socket.on("disconnect", function() {
        console.log("A student disconnected:", socket.id);
    });

    socket.on("code-change", function(data) {
    socket.to(data.roomId).emit("code-update", data.code);
    });
});

app.get("/", function(req, res) {
    res.send("DoubtDuo Backend is Running!");
});

server.listen(3000, function() {
    console.log("DoubtDuo server is running on port 3000");
});
